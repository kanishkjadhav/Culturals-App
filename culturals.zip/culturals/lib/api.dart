final baseURL = 'https://gymkhana.iitb.ac.in/~cultural/api/';

final loginURL = baseURL + 'login.php';
final profileURL = baseURL + 'profile.php?rollno=';
final profileUpdateURL = baseURL + 'profile_update.php';

final eventsURL = baseURL + 'events.php?page=';
final eventsPastURL = baseURL + 'events_past.php?page=';

final notificationsURL = baseURL + 'notifications.php?page=';

final infoURL = baseURL + 'info.php';
